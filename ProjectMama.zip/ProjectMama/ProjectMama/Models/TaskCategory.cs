﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProjectMama.Models
{
    public class TaskCategory
    {
        uint tid { get; set; }
        uint cid { get; set; }
    }
}