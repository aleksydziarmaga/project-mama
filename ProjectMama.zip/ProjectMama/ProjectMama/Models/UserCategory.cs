﻿namespace ProjectMama.Models
{
    public class UserCategory
    {
        uint uid { get; set; }
        uint cid { get; set; }
    }
}