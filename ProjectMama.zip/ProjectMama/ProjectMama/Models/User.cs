﻿namespace ProjectMama
{
    public class User
    {
        public uint id { get; set; }
        public string name { get; set; }
        public string mail { get; set; }
        public string password { get; set; }
    }
}
