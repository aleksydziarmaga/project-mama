﻿namespace ProjectMama
{
    class Category
    {
        public uint id { get; set; }
        public string name { get; set; }
    }
}
